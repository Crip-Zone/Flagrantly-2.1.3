<?php
$txt['Navigate'] = 'Navigate';
$txt['Design'] = 'Design';
$txt['copyrights'] = 'Copyrights';
$txt['themecopyright'] = 'Flagrantly by <a href="https://www.jpr62.com/theme/" target="_blank" class="new_win" title="Crip Zone">Crip</a> <br> Updated for SMF 2.1<br>By <a href="https://www.jpr62.com/theme/" target="_blank" class="new_win" title="TheCripZone">TheCripZone</a>';
?>