<?php
// Version: 2.1.0; Settings

global $settings;

// argument(s): images_url as saved in settings
$txt['theme_thumbnail_href'] = '%1$s/thumbnail.png';
$txt['theme_description'] = 'The Flagrantly theme from Crip Zone Themes.<br><br>Author: Crip<br><br>Updated to v2.1 by TheCripZone:<br>Skhilled, Dave, TwitchisMental<br><br>';
?>